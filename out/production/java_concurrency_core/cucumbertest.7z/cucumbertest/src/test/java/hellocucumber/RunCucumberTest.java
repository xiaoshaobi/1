//package hellocucumber;
//
//import io.cucumber.junit.Cucumber;
//import io.cucumber.junit.CucumberOptions;
//import org.junit.runner.RunWith;
//
///**
// * feature文件的扫描是根据RunCucumberTest所在目录，在classpath对应的目录下去扫描。如果图中的例子，
// * 默认扫描classpath:hellocucumber目录下的文件。也可显示指定扫描的路径
// */
//@RunWith(Cucumber.class)
//@CucumberOptions(plugin = {"pretty"})
//public class RunCucumberTest {
//}
